## Quickstart

Get state of the art text classification for 10% of LLM API prices.
- Finetune your own LLMs on 1 GPU for text classification.
- No GPU? No problem: switch to remote GPU finetuning using Modal with one line of code. Deploy in 1 line with Modal.
- Full control: keep your models, export weights for VLLM / Ollama, set custom training params, bring your own finetuning data, bring your own prompts

1. Run a simple classifier via API.  
```python
from predictors.predictors import ZeroShotPredictor
from predictors.tasks import Predict, Classify, ClassifierClass
tasks = [
    Predict(
        name="square",
        description="What is the square of this number?",
        dtype='int'),
    Classify(
        name="is_prime",
        description="Is this prime number?",
        classes=[
            ClassifierClass(name="yes", description="Yes"),
            ClassifierClass(name="no", description="No"),
        ]
    )        
]
X = ["1", "2", "3", "3"]
cls = ZeroShotPredictor(
    tasks=tasks,
    model="gpt-4o",
)
print(cls.predict(X))
```

2. Finetune your own LLM classifier remotely via modal + unsloth. 

Set up Modal for remote training. 
> modal setup

```python
from predictors.predictors import FineTunedPredictor
from predictors.tasks import Classify, Predict
finetuned_model_name = "mjrdbds/llama3-4b-classifierunsloth-20240516-lora"
base_model_name = "unsloth/llama-3-8b-bnb-4bit"
n = FineTunedPredictor(
    model=finetuned_model_name,
    base_model_name=base_model_name,
    remote=True,
)
n.set_config(
    tasks=[Classify(name="classify", description="Classify the category of the input"),
            Predict(
                name="price",
                description="The price of the input product.")
    ], 
    prompt_template_file='classification_labels.jinja'
)
X = ["the product is not a piece of furniture", "the product is a piece of furniture"]
y = [{'classify': 'not furniture', 'price': 5}, {'classify': 'furniture', 'price': 10}]
n.fit(X, y)
print(n.predict(X))
```

Predictors are saved locally or to a Modal volume. They persist from one session to the next, reloading from disc.  
```python
from predictors.predictors import FineTunedPredictor
finetuned_model_name = "mjrdbds/llama3-4b-classifierunsloth-20240516-lora"
base_model_name = "unsloth/llama-3-8b-bnb-4bit"
n = FineTunedPredictor(
    model=finetuned_model_name,
    base_model_name=base_model_name,
    remote=True,
)
X = ["the product is not a piece of furniture", "the product is a piece of furniture"]
y = [{'classify': 'not furniture', 'price': 5}, {'classify': 'furniture', 'price': 10}]
print(n.predict(X)) # no need to retrain.
```

## Contribute

This is a POC. We're looking for contributors, DM [me](https://x.com/baptiste_cumin). 

Features:
1. Improve remote training performance. Load less 